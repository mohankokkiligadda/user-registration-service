package io.upscaling.user.model;

public enum LoginStatus {
    SUCCESS, UN_AUTHORIZED;
}
